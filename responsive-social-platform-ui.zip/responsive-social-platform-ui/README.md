# Responsive Social Platform UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/TurkAysenur/pen/RwWKYMO](https://codepen.io/TurkAysenur/pen/RwWKYMO).

Inspired By Quan Ha
https://dribbble.com/shots/5581599-027-100-Daily-UI-Intranet-Employee-Profile